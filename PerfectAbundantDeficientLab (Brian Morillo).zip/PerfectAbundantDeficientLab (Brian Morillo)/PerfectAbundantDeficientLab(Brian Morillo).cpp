// Description: This program classifies a positive number as Perfect, Deficient or Abundant.
// Project Title: Perfect Abundant Deficient Lab
// Programmer: Brian Morillo
// Last Modified: 4/2/2021, 7:00 PM

#include <iostream>
using namespace std;

int main()
{
	system("title Classify a POSITIVE number as Deficient, Perfect or Abundant by B.Morillo");
	system("color E1");

	// Variables
	int userNumber;
	int sumOfFactors;

	// Banner section
	cout << "\n"
		<< "\t\t Positive number classification as \n"
		<< "\t\t  perfect, abundant, or deficient  \n"
		<< "\t\t            by  B.Morillo          \n";

	while (true)
	{
		sumOfFactors = 0;

		cout << "\n\n"
			<< "Enter a number to be classified as perfect, abundant, or deficient: ";
		cin >> userNumber;
		cin.ignore(2147483647, '\n');

		while (userNumber <= 0) {
			cout << "This classification is for POSITIVE integers only. Please try again: ";
			cin >> userNumber;
			cin.ignore(2147483647, '\n');
		}

		for (int num = 1; num < userNumber; num++)
		{
			if (userNumber % num == 0)
				sumOfFactors += num;
		}

		cout << "\t" << userNumber << " is " << (userNumber == sumOfFactors ? "a PERFECT" : "") 
			<< (userNumber > sumOfFactors ? "a DEFICIENT" : "") 
			<< (userNumber < sumOfFactors ? "an ABUNDANT" : "") << " number.\n"
			<< "    *********************************************************************";
	}

	return 0;
}
