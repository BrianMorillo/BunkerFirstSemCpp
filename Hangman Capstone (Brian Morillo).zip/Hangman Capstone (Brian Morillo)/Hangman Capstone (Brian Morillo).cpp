// Description: This programs picks a random word from a file to play hangman with
// obsrve the grammar, validate the file opened correctly
// letter that are differenct case count as correct
// don't take attemps off if the same letter was guessed more than once
// Title: Hangman Capstone
// Programmer: Brian Morillo	
// Last Date Modified: 5/3/2021 @ 7:00 AM

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

void printBanner();
ifstream connectFile(string& filename);
int wordCountInFile(ifstream& ifs);
string getWordFromFile();
int calcStringLength(string str);
void gameSetUp(string& wordToFind, string& playerGuess, int& wordLength, int guessesAllowed = 5);
void printInitialMessage(int wordLength, string playerGuess, int guessesAllowed = 5);
char getALetter();
bool isLetter(char ch);
char getLetterGuess();
bool isLowerCase(char ch);
char upperToLower(char ch);
bool existsInString(char ch, string word);
void printResults(string wordToFind, int correctLettersCount);
string initiallizePlayerGuess(int wordLength);
void notInTheWordMessageAndUpdates(char letterGuess, int& wrongGuesses, int guessesAllowed = 5);
void correctLetterMessage(char ch, string playerGuess, int wrong, int allowed = 5);
void correctLetterUpdates(char ch, string wordToFind, string& playerGuess, int& correct);
void printStringSpacedOut(string word);
bool isUpperCase(char ch);
char changeTolowerIfUpper(char ch);

int main() {  // DONE
	system("title Hangman Capstone Project Select a random word from a dictionary == by B. Morillo");
	system("color E1");

	string wordToFind, playerGuess, guesses;
	int wordLength, wrongGuesses, correctLettersCount, guessesAllowed = 5;
	char letterGuess;

	printBanner();

	while (true) {
		guesses = "";
		wrongGuesses = 0, correctLettersCount = 0;
		gameSetUp(wordToFind, playerGuess, wordLength, guessesAllowed);

		while (playerGuess != wordToFind && wrongGuesses != guessesAllowed) {
			cout << "\nWhat is your letter guess? ";
			letterGuess = getLetterGuess();

			if (existsInString(letterGuess, guesses))
				cout << "   You have already guessed that letter!\n";
			else {
				guesses += letterGuess;

				if (existsInString(letterGuess, wordToFind)) {
					correctLetterUpdates(letterGuess, wordToFind, playerGuess, correctLettersCount);
					correctLetterMessage(letterGuess, playerGuess, wrongGuesses, guessesAllowed);
				}
				else
					notInTheWordMessageAndUpdates(letterGuess, wrongGuesses, guessesAllowed);
			}
		}

		printResults(wordToFind, correctLettersCount);
		cout << "\a\n\n      *************************************\n";
	}

	system("pause");
	return 0;
}

void printBanner() {  // DONE
	cout << "\n"
		<< "\t   ****   Welcome to Hangman by B.Morillo   ****         \n"
		<< "\n"
		<< "\t            Hangman Capstone Sample Solution             \n"
		<< "\t                      by B. Morillo                      \n"
		<< "\tword to be guessed is randomly selected from a dictionary\n"
		<< "\t                  file open validation                   \n"
		<< "\t              seeded random number generator             \n"
		<< "\t             strings, while loops, for loops             \n"
		<< "\t                   searching \"arrays\"                  \n"
		<< "\t      bool functions, validation functions, etc.         \n"
		<< "\t         by reference and optional arguments             \n"
		<< "\t                        counters                         \n";
}

ifstream connectFile(string& fileName) {  // DONE
	ifstream inputFile;
	inputFile.open(fileName);

	while (!inputFile) {
		cout << "\a  xxx  Failed to open \"" << fileName << "\". Please check the file name and try again: ";
		getline(cin >> ws, fileName);
		inputFile.open(fileName);
	}
	return inputFile;
}

int wordCountInFile(ifstream& ifs) {  // DONE
	int wordCount = 0;
	string word;

	while (ifs >> word)
		wordCount++;

	return wordCount;
}

string getWordFromFile() {  //  DONE
	string fileName, randomWord;
	ifstream file;
	int wordCount, randomWordLength;
	unsigned seed;

	getline(cin >> ws, fileName);
	file = connectFile(fileName);

	wordCount = wordCountInFile(file);
	cout << "There " << (wordCount != 1 ? "are " : "is ") << wordCount
		<< " word" << (wordCount != 1 ? "s" : "") << " in your file.\n";

	file.close();

	seed = time(0);
	srand(seed);
	randomWordLength = (rand() % wordCount) + 1;

	file = connectFile(fileName);
	for (int index = 0; index < randomWordLength; index++)
		file >> randomWord;

	file.close();

	return randomWord;
}

int calcStringLength(string str) {   // DONE
	int stringLength = 0;
	//	for (char letter : str)  // have here an old fashined loop - bodyless
		// the final solution would be a bodyless while loop - sentinell terminaed while
	for (; str[stringLength] != '\0';stringLength++);
	//	while (str[stringLength] != '\0')  // avoid using chars as bool use the relational operator with no magic numbers
	//		stringLength++;

	return stringLength;
}

void gameSetUp(string& wordToFind, string& playerGuess, int& wordLength, int guessesAllowed) {  // DONE
	// getWordFomFile
	// need to find the number of letters in the word
	// "_ _ _ .."
	// print the intial message 
	cout << "\nWhich file contains your words? ";
	wordToFind = getWordFromFile();

	wordLength = calcStringLength(wordToFind);

	playerGuess = initiallizePlayerGuess(wordLength);

	printInitialMessage(wordLength, playerGuess, guessesAllowed);
}

void printInitialMessage(int wordLength, string playerGuess, int guessesAllowed) {  // DONE
	cout << "\tThe word you need to find has " << wordLength << " letters.\n";
	cout << "\tYou have a total of " << guessesAllowed << " attempts to find the word.\n\n";

	cout << "\t";
	printStringSpacedOut(playerGuess); //   your playerGuess is ___ instead of _ _ _
	cout << "\n\n";
}

char getLetterGuess() {  // DONE
	char guess = getALetter();

	if (!isLowerCase(guess))
		guess = upperToLower(guess);

	return guess;
}

char getALetter() {  // DONE
	char input;

	cin >> input;
	cin.ignore(300000, '\n');

	while (!isLetter(input)) {
		cout << "\a   \'" << input << "\' is not a letter. Try again : ";
		cin >> input;
		cin.ignore(300000, '\n');
	}

	return input;
}

bool isLetter(char ch) {    // DONE
	return isUpperCase(ch) || isLowerCase(ch);
}

bool isLowerCase(char ch) {  // DONE
	return ch >= 'a' && ch <= 'z';
}

bool isUpperCase(char ch) {   // DONE
	return ch >= 'A' && ch <= 'Z';
}

char upperToLower(char ch) {   // DONE
	return ch + ('a' - 'A');
}

bool existsInString(char ch, string word) {  // DONE
	for (char letterInWord : word) {
		if (ch == changeTolowerIfUpper(letterInWord))
			return true;
	}
	return false;
}

void notInTheWordMessageAndUpdates(char letterGuess, int& wrongGuesses, int guessesAllowed) {   // DONE
	wrongGuesses++;

	cout << "\a   \'" << letterGuess << "\' is NOT in the word.\n";
	cout << "   Now you have " << wrongGuesses << " wrong guess" << (wrongGuesses != 1 ? "es" : "") << " and "
		<< (guessesAllowed - wrongGuesses) << " attempt" << (guessesAllowed - wrongGuesses != 1 ? "s" : "")
		<< " left.\n";
}

void printResults(string wordToFind, int correctLettersCount) { // DONE
	if (correctLettersCount == calcStringLength(wordToFind))  // because he doesn't store spaces in between that will work
		cout << " ****   Congratulations you found the word!   ****\n";
	else {
		cout << "\n   Sorry you lost that round! Better luck next time!\n";
		cout << "   The word was \"" << wordToFind << "\"";   // since there are no spaces that will work
	}
}

string initiallizePlayerGuess(int wordLength) {  // DONE (doesn't have spaces in between the _) he addresses that elsewhere
	string playerGuess = "";

	for (int index = 0; index < wordLength; index++)
		playerGuess += "_";

	return playerGuess;
}

void correctLetterMessage(char ch, string playerGuess, int wrong, int allowed) {  // DONE
	cout << "   \'" << ch << "\' IS in the word.\n";
	cout << "   You still have " << (allowed - wrong) << " attempt" << (allowed - wrong != 1 ? "s" : "") << " left.\n\n";
	cout << "  ***  So far you have ";

	printStringSpacedOut(playerGuess);   // compensated for the missing _ create a function for this printStringSpacedOut
	cout << "\n\n";
}

void correctLetterUpdates(char ch, string wordToFind, string& playerGuess, int& correct) {
	//	for (char letterInWord : wordToFind) {   // convert to old fashioned for
	for (int index = 0; index < calcStringLength(wordToFind); index++) {
		if (ch == changeTolowerIfUpper(wordToFind[index])) {
			playerGuess[index] = wordToFind[index];
			correct++;
		}
	}
}

void printStringSpacedOut(string word) {
	//for (char letter : word)  // pratice arrays
	for (int index = 0; index < calcStringLength(word); index++)
		cout << changeTolowerIfUpper(word[index]) << " ";
}

char changeTolowerIfUpper(char letter) {  // DONE
	return (isUpperCase(letter) ? upperToLower(letter) : letter);
}
