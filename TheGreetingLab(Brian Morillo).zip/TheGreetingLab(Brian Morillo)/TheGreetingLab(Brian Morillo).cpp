// Description: This program reads the full name inputted (even with spaces and multiple "parts"),
// and then greets the person appropriately.
// Project Title: The Greeting Lab	
// Programmer: Brian Morillo
// Last Modified: 2/26/2021, 8:00 PM

#include <iostream>
#include <string>
using namespace std;

int main()
{
	system("title .    The Greeting Lab with strings and ws manipulator   by B.Morillo");
	system("color E1");

	string fullName;

	cout << "\n"
		<< "\t\t       The greeting lab          \n"
		<< "\t\t         with strings            \n"
		<< "\t\t using the ws stream manipulator \n"
		<< "\t\t         by B. Morillo           \n";

	while (true) {
		cout << "\n\nWhat is your FULL name? ";
		getline(cin >> ws, fullName);
		cout << "Hello \"" << fullName << "\". \n\n";
		system("pause");
	}
	
	return 0;
}
