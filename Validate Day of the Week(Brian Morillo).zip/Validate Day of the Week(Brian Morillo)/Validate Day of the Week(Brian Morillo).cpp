// Description: This program validates if an inputted character
// matches with a day from the week
// Project Title: Day of the Week with Validation
// Programmer: Brian Morillo
// Last Modified: 3/19/2021, 6:00 PM

#include <iostream>
using namespace std;

int main()
{
	system("title Day of the Week with Validation - no magic number or library functions by  B.Morillo");
	system("color E1");

	// Constants for the codes of each days
	const char
		MONDAY_CODE = 'M',    // Code for Monday
		TUESDAY_CODE = 'T',   // Code for Tuesday
		WEDNESDAY_CODE = 'W', // Code for Wednesday
		THURSDAY_CODE = 'H',  // Code for Thursday
		FRIDAY_CODE = 'F',    // Code for Friday
		WEEKEND_CODE = 'S';   // Code for Weekend

	// Variables
	char dayCode;  // variable to input the day code to.

	// Banner section
	cout << "\n"
		<< "\t Find the day of the week using switch case \n"
		<< "\t    validate input FIRST using while loop   \n"
		<< "\t                 by  B.Morillo              \n";

	// Instructions
	cout << "\n"
		<< "  ****************************************************************************\n"
		<< "  *  You should have ONLY ONE input validation loop to check if the day code *\n"
		<< "  *  Make sure you that loop test ALL possible UNACCEPTABLE situations       *\n"
		<< "  *  If unacceptable input is found                                          *\n"
		<< "  *            change the console color to b1 and                            *\n"
		<< "  *            beep to attract the user's attention                          *\n"
		<< "  *  Consider using the conditional operator to customize your feedback      *\n"
		<< "  *            (i.e. digit vs special char) INSIDE that loop.                *\n"
		<< "  *  AFTER you validate that the input is valid                              *\n"
		<< "  *            restore the console color and                                 *\n"
		<< "  *            check if it is NOT capital and convert if needed              *\n"
		<< "  *  You are NOT allowed to use                                              *\n"
		<< "  *             the ASCII values of ANY character                            *\n"
		<< "  *             any library functions, like the                              *\n"
		<< "  *             isdigit, isupper, toupper, isalnum, isalpha, etc.            *\n"
		<< "  ****************************************************************************\n\n";

	// Display days of the week and their assigned characters
	cout << "\n"
		<< "  Day codes are:   \n"
		<< "  `" << MONDAY_CODE << "' for Monday       \n"
		<< "  `" << TUESDAY_CODE << "' for Tuesday     \n"
		<< "  `" << WEDNESDAY_CODE << "' for Wednesday \n"
		<< "  `" << THURSDAY_CODE << "' for Thursday   \n"
		<< "  `" << FRIDAY_CODE << "' for Friday       \n"
	    << "  `" << WEEKEND_CODE << "' for Weekend";

	while (true)
	{
		// Gets the day code from the user
		cout << "\n\n\nPlease enter the code of the day of the week you want: ";
		cin >> dayCode;
		cin.ignore(2147483647, '\n'); 

		// Validation loop
		while ((dayCode < 'A' || dayCode > 'Z') && (dayCode < 'a' || dayCode > 'z'))
		{
			// Changes color due to invalid input
			system("color B1");
			
			cout << "\a   You can NOT have " << (dayCode < '0' || dayCode > '9' ? "SPECIAL CHARACTERS" : "DIGITS") <<" for days code in this program.\n";
			cout << "   Please give a letter code: ";
			cin >> dayCode;
			cin.ignore(2147483647, '\n');
		}

		//Capitalizes code in case it is lowercase
		if (dayCode >= 'a' && dayCode <= 'z')
		{
			cout << "\n  Remember that proper nouns start with capital.\n"
				 << "  You should have typed `" << (dayCode -= ('z' - 'Z')) << "'\n";
		}

		// Changes color back to normal
		system("color E1");

		// Outputs the selected day
		cout << "\n  ****   Your day is : ";
		switch (dayCode) 
		{
			case MONDAY_CODE: cout << "Monday.";
				break;
			case TUESDAY_CODE: cout << "Tuesday.";
				break;
			case WEDNESDAY_CODE: cout << "Wednesday.";
				break;
			case THURSDAY_CODE: cout << "Thursday.";
				break;
			case FRIDAY_CODE: cout << "Friday.";
				break;
			case WEEKEND_CODE: cout << "Weekend.";
				break;
			default : cout << "No such day.";
		}
	}

	return 0;
}
