// Description: This Program adds two integers
// Project Title: Two integer adder	
// Programmer: Brian Morillo
// Last Modified: 2/19/2021, 12:00 PM

#include <iostream>
using namespace std;

int main()
{
	system("title .                     Two INTEGER Adder     by B.Morillo");
	system("color E1");

	int num1, num2;

	cout << "\n"
		<< "\t\t    Two integer adder \n"
		<< "\t\t         Improved        \n"
		<< "\t\t       by B. Morillo     \n\n\n";

	cout << "Please enter an INTEGER: ";
	cin >> num1;
	cin.ignore(2147483647, '\n');
	cout << "Please enter an other INTEGER: ";
	cin >> num2;
	cin.ignore(2147483647, '\n');

	cout << "\nThe sum of " << num1 << " and " << num2 << " is: " << num1 + num2 << ".\n"
		<< "       \"" << num1 << " + " << num2 << "\" = " << num1 + num2 << "\n\n";

	system("pause");
	return 0;
}
