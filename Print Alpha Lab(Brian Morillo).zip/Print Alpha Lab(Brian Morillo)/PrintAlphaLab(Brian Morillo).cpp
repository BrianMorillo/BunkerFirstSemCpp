// Description: This prints out the desired part of the alphabet in columns and rows
// Project Title: Print Alpha Lab
// Programmer: Brian Morillo
// Last Modified: 4/16/2021 1:51 PM

#include <iostream>
using namespace std;

// Prototypes are good
void printBanner();
void printAlpha(char start = 'A', char end = 'Z', int n = 5);
char getYorN();
char getLetter();
int  getPosInt();
bool isUpper(char letter);
char getSameCaseLetter(char letter);
char getSameCaseAfter(char letter);
char getUpperCase();
char getLowerCase();
bool isLower(char letter);

int main()
{
	system("title PrintAlpha function with optional arguments and driver that validates ALL precondition in multiple functions");
	system("color E1");

	char start;
	char end;
	int n;

	printBanner();
	
	cout << "\nCalling \"printAlpha()\"\n"
		<< "\tPrinting from A to Z, 5 characters per line:\n\n";
	printAlpha();

	cout << "\n\nCalling \"printAlpha(\'T\')\"\n"
		<< "\tPrinting from T to Z, 5 characters per line:\n\n";
	printAlpha('T');

	cout << "\n\nCalling \"printAlpha(\'C\',\'W\')\"\n"
		<< "\tPrinting from C to W, 5 characters per line:\n\n";
	printAlpha('C', 'W');

	cout << "\n\nCalling \"printAlpha(\'D\',\'Y\',\'3\')\"\n"
		<< "\tPrinting from D to Y, 3 characters per line:\n\n";
	printAlpha('D', 'Y', 3);

	cout << "\n\nDo you want to choose the arguments? ";
	while (getYorN() == 'Y')  // this will be the condition to loop
	{
		cout << "\nPeoples' choice! ;) \n";
		
		cout << "\tEnter the STARTING letter: ";
		start = getLetter();
		cout << "\tEnter the ENDING letter: ";
		end = getSameCaseAfter(start);
		cout << "\tHow many letters do you want me to print per line\n"
			<< "\t   (if you hit ENTER I will use the default value): ";

		if (cin.peek() == '\n')
		{
			cout << "\nCalling \"printAlpha(\'" << start << "\', \'" << end << ")\"\n\n";
			printAlpha(start, end);
		}
		else {
			n = getPosInt();

			cout << "\nCalling \"printAlpha(\'" << start << "\', \'" << end << "\', " << n << ")\"\n\n";
			printAlpha(start, end, n);
		}

		cout << "\n\nDo you want to choose the arguments? ";
	}

	cout << "\nThank you for printing with us!\n\n";
	system("pause");
	return 0;

}

void printAlpha(char start, char end, int n)
{
	for (char currentLetter = start; currentLetter <= end; currentLetter++)
		cout << currentLetter << ((currentLetter - start + 1) % n == 0? "\n" : "\t");
}

void printBanner()   // DONE
{
	cout << "\n"
		<< "\t\tLab on Optional Arguments\n"
		<< "\t\t        by B.Morillo      \n\n";
}

char getYorN() {  // DONE
	char yOrN;

	cin >> yOrN;
	cin.ignore(100000, '\n');

	while (yOrN != 'Y' && yOrN != 'N' && yOrN != 'n' && yOrN != 'y') {
		cout << "Please type Y or N. Try again: ";
		cin >> yOrN;
		cin.ignore(100000, '\n');
	}

	return (yOrN == 'Y' || yOrN == 'y') ? 'Y' : 'N';
}

char getLetter() {   // DONE
	char letter;

	cin >> letter;
	cin.ignore(100000, '\n');

	while ((letter < 'a' || letter > 'z') && (letter < 'A' || letter > 'Z')) {
		cout << "\'" << letter << "\' is not a letter! Please enter a letter: ";
		cin >> letter;
		cin.ignore(100000, '\n');
	}

	return letter;
}

int getPosInt() {  // DONE
		double number;

		cin >> number;
		cin.ignore(100000, '\n');

		while (number < 0 || number != static_cast<int>(number)) { 
			cout << "\t" << number << " is not a" << (number < 0 ? " POSITIVE" : "") 
				<< (number - static_cast<int>(number) != 0 ? " WHOLE" : "") << " number. Try again: ";
			cin >> number;
			cin.ignore(100000, '\n');
		}

		return static_cast<int>(number);
}

bool isUpper(char letter) {  // DONE
	return letter >= 'A' && letter <= 'Z';
}

bool isLower(char letter) {   // DONE
	return letter >= 'a' && letter <= 'z';
}

char getSameCaseAfter(char letter) {  // DONE
	char userInput = getSameCaseLetter(letter);

	while (userInput < letter) {
		cout << "\tEnd letter must be after than starting letter.\n"
			<< "\tTry again: ";
		userInput = getSameCaseLetter(letter);
	}

	return userInput;
}

char getSameCaseLetter(char letter) {  // DONE
	return (isUpper(letter) ? getUpperCase() : getLowerCase());
}

char getUpperCase() {  // DONE
	char userInput = getLetter();

	while (!isUpper(userInput)) { 
		cout << "\tPlease enter an UPPER case letter. Try again : ";
		userInput = getLetter();
	}

	return userInput;
}

char getLowerCase() {   // DONE
	char userInput = getLetter();

	while (!isLower(userInput)) {
		cout << "\tPlease enter a LOWER case letter. Try again : ";
		userInput = getLetter();
	}

	return userInput;
}