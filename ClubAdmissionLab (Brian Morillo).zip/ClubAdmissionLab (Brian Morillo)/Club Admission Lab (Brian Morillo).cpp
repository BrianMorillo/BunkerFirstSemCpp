// Description: This program admits customers by name and 
// between the age of 21(Inclusive) and 40(Exclusive) into a club.
// Project Title: The Club Admission
// Programmer: Brian Morillo
// Last Modified: 3/8/2021, 8:00 PM
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main()
{
	system("title .      The \"Club Admission\" Lab with strings and ws manipulator === by B.Morillo");
	system("color E1");

	// Constants for minimum and maximum age acceptance
	const int
		MIN_AGE = 21, // Minimum acceptance age(INclusive)
		MAX_AGE = 40; // Maximum acceptance age(EXclusive)

	// Variables
	string fullName;  // Customers full name
	double age;		  // Customers age

	// Banner section
	cout << "\n"
		<< "\t                    The \"club admission\" lab                                           \n"
		<< "\t                    note that age is a double                                            \n"
		<< "\t                      needs an if ... else                                               \n"
		<< "\t                loops for ever for easy testing                                          \n"
		<< "\t               uses named consts for easy updates                                        \n"
		<< "\t       ONLY customers with age in [" << MIN_AGE << ", " << MAX_AGE << ") are allowed in  \n"
		<< "\t  avoid entering more than 13 decimal places (rounding issues)                           \n"
		<< "\t                         by B. Morillo                                                   \n";

	while (true) {
		// Get the customers name
		cout << "\n\nWhat is your FULL name? ";
		getline(cin >> ws, fullName);

		// Get the customers age
		cout << "How old are you \"" << fullName << "\"? ";
		cin >> age;
		cin.ignore(2147483647, '\n');

		// Validate the input.
		if (age >= MIN_AGE && age < MAX_AGE)
			// Display acceptance message
			cout << "        Welcome to the club " << fullName << "! \n\n";
		else {
			// Display denial message
			cout << "        Sorry, you need to be between " << MIN_AGE << " (INclusive) and " << MAX_AGE << " (EXclusive)\n"
				 << "        to be eligible to enter this establishment and\n"
				 << "        you are " << (age < MIN_AGE ? "only " : "") << age << " years old.\n\n";
		}

		// clean up section 
		cout << "Next customer please!\n";
		system("pause");
	}

	return 0;
}
