//Description: This program prints my name
//Project Title: PrintMyName
//Programmer: Brian Morillo
//Last Modified: 2/5/2021, 1:45 PM

#include <iostream>
using namespace std;

int main()
{
	system("title .              Print My Name       by B.Morillo");
	system("color 5F");

	cout << "\n"
		<< "\tThis lab prints my name on the Monitor  \n"
		<< "\t           within double quotes         \n"
		<< "\t                 Lab #1				  \n"
		<< "\t              by B. Morillo             \n\n\n";

	cout << "\"Brian Morillo\"\n\n";

	system("pause");
	return 0;
}
